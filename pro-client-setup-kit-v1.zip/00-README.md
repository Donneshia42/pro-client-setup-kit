# Pro Client Setup Kit for New Coaches — v1

Thank you for purchasing. This kit gets you from “send me money and we’ll meet” to a professional client flow in one evening.

## What’s inside
1. `01-coaching-agreement-TEMPLATE.md` — customize and use as a starting point. **Not legal advice.**
2. `02-client-intake-form.md` — copy into Google Forms or print.
3. `03-welcome-packet.md` — paste into a Google Doc / Canva and brand it.
4. `04-email-welcome.md`, `05-email-before-session-1.md`, `06-email-after-session-1.md`
5. `07-stripe-and-booking-checklist.md` — Stripe Payment Link + booking setup with mindset notes on charging upfront.

## How to use tonight
1. Skim the checklist (`07`) first so you know the end state.
2. Customize the agreement TEMPLATE with your name, rates, and policies. Have a licensed attorney in your area review before you rely on it.
3. Build the intake form (Google Forms works fine).
4. Brand the welcome packet.
5. Create your Stripe Payment Link and booking link using the checklist.
6. Paste the three emails into your notes / Gmail templates.

## Support
Questions: support@manifestmiraclecoachingwithdonneshia.com

## Refunds
If this kit isn’t useful within 7 days of purchase, email support with your receipt. Full refund, no drama.

— Donneshia Marrs, Manifest Miracle Coaching
