# Client Intake Form (copy into Google Forms or print)

**Instructions for the coach:** Create a Google Form with these questions. Turn on “Collect email addresses.” Share the form link in your welcome email. Keep responses in a private Drive folder.

## Section A — Basics
1. Full name  
2. Preferred name / pronouns  
3. Email  
4. Phone (optional)  
5. Time zone  
6. How did you find me?

## Section B — Goals
7. What do you most want to change or create in the next 90 days?  
8. What would “success” look like after our work together? (Be specific.)  
9. What’s already working that you want to keep?  
10. On a scale of 1–10, how ready are you to take action weekly?

## Section C — Context (optional; Client may skip)
11. Anything I should know so I can support you well? (life transitions, constraints, preferences)  
12. Are you currently working with a therapist, counselor, or other professional? ☐ Yes ☐ No ☐ Prefer not to say  
13. Coaching is not therapy. If you need clinical support, please continue (or seek) licensed care. Understood? ☐ Yes

## Section D — Logistics
14. Preferred session days/times  
15. Preferred format: Zoom / Phone / Other  
16. Emergency contact name + phone (optional; for no-show wellness checks only if you choose to use it)  
17. Anything else you want me to know before Session 1?

## Coach note (mindset)
You are not collecting a medical history. Keep questions respectful. Store responses securely. Never share a client’s answers publicly.
