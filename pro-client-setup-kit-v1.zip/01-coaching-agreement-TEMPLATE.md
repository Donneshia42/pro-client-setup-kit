# Coaching Agreement — TEMPLATE

> **IMPORTANT — NOT LEGAL ADVICE**  
> This is a **template** for educational and business-setup purposes only. It is **not** a substitute for advice from a licensed attorney in your jurisdiction. Coaching is not therapy, counseling, or medical care. Customize this document, then have a qualified attorney review it before you use it with clients. By using this template you accept that the seller and Manifest Miracle Coaching LLC are not providing legal services and are not liable for how you use it.

**Date:** ________________  
**Coach:** [Your Legal Name / Business Name] (“Coach”)  
**Client:** [Client Full Name] (“Client”)  
**Email:** ________________  **Phone:** ________________

## 1. Scope of coaching
Coach provides 1:1 life / mindset coaching. Coaching is a partnership focused on goals, mindset, accountability, and action.  
**Coaching is not:** therapy, psychotherapy, counseling, medical or mental-health treatment, financial/legal/tax advice, or a guarantee of any specific outcome (income, relationships, health, etc.).

If Client is in crisis or needs clinical care, Client agrees to seek appropriate licensed professionals / emergency services. Coach may pause or end coaching if Coach believes Client needs support outside Coach’s scope.

## 2. Services & schedule
- Package / session type: ________________________________
- Number of sessions / length: ____________________________
- Session format: ☐ Zoom  ☐ Phone  ☐ In person  ☐ Other: ______
- Session length: ______ minutes
- Start date: ______________ End date / review date: ______________

Rescheduling: Client will give at least **24 hours** notice to reschedule. Late cancels / no-shows may be counted as a used session (Coach’s policy: ________________).

## 3. Fees & payment
- Total fee: $__________  
- Payment schedule: ☐ Pay in full before start  ☐ Installments: ______________  
- Method: Stripe Payment Link / other: ________________  
- Sessions are reserved only after payment clears (unless Coach agrees otherwise in writing).

Returned / failed payments may pause scheduling until resolved.

## 4. Refund & cancellation
- Client may cancel unused prepaid sessions with written notice.  
- Refund policy (choose & customize):  
  ☐ No refunds after first session begins  
  ☐ Pro-rated refund for unused sessions minus $____ admin fee  
  ☐ Other: ________________________________  
- Coach may terminate for non-payment, scope issues, or disrespectful conduct, with written notice. Unused prepaid sessions: ________________________________.

## 5. Confidentiality
Coach keeps Client information private except when: (a) Client gives written permission; (b) required by law; (c) there is a risk of harm to self/others; (d) a valid legal process requires disclosure. Coach may use anonymized, non-identifying examples for teaching only if Client agrees: ☐ Yes ☐ No.

## 6. Client responsibilities
Client agrees to show up on time, be honest, do agreed actions between sessions, and communicate needs. Results depend on Client’s effort; Coach does not guarantee outcomes.

## 7. Intellectual property
Worksheets, templates, and materials Coach shares remain Coach’s IP. Client may use them personally; Client may not resell or redistribute without written permission.

## 8. Limitation of liability
To the fullest extent allowed by law, Coach’s total liability under this agreement is limited to fees Client actually paid for the coaching services in the 3 months before the claim. Coach is not liable for indirect or consequential damages.

## 9. Governing law
This agreement is governed by the laws of the State of ______________, without regard to conflict-of-law rules.

## 10. Entire agreement
This document (plus any attached schedule) is the entire agreement. Changes must be in writing and signed (or clearly agreed by email) by both parties.

---

**Client signature:** ________________________ Date: ________  
**Print name:** ________________________

**Coach signature:** ________________________ Date: ________  
**Print name:** ________________________

*Again: TEMPLATE ONLY — not legal advice. Get local attorney review before use.*
