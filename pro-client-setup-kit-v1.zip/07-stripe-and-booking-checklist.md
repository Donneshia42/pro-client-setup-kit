# Stripe Payment Link + Booking Checklist (with mindset)

Goal: client pays → gets welcome email → fills intake → signs agreement → books Session 1. You look professional without an expensive all-in-one platform.

## Mindset (read this first)
Feeling “unprofessional” usually means your *system* is messy — not that *you* are. Charging upfront is respectful: it protects your calendar and signals that coaching is real work. You are allowed to get paid before you give your energy.

## Part A — Stripe Payment Link (≈15–20 min)
1. Create / log in to Stripe (use live mode only when you’re ready for real money).  
2. Products → Add product → name it clearly, e.g. “6-session coaching package — [Your Name]”.  
3. Set price (one-time or recurring).  
4. Create a **Payment Link** for that price.  
5. After payment, set the confirmation / redirect to a thank-you page that says “check your email for next steps” (or your delivery page).  
6. Copy the Payment Link into your welcome packet, Beacons, and Instagram bio as needed.  
7. Test with Stripe **test mode** and card `4242 4242 4242 4242` before you share a live link.

## Part B — Booking link (pick one)
**Option 1 — Google Calendar Appointment schedules**  
- Google Calendar → Create → Appointment schedule → set duration, availability, buffer.  
- Share the booking page link.

**Option 2 — Calendly (free tier is fine for v1)**  
- One event type (e.g. “Coaching Session — 60 min”).  
- Require invitee email; add a question: “Payment completed? (yes/receipt email)”.

Put the booking link in Email 1 (welcome). Optional advanced: only send the booking link after payment (manual is fine for your first 10 clients).

## Part C — Wire the flow tonight
- [ ] Stripe Payment Link live (or test-proven)  
- [ ] Intake Google Form live  
- [ ] Agreement Doc ready (attorney-reviewed when possible)  
- [ ] Welcome packet PDF or Doc  
- [ ] Three emails saved as Gmail templates  
- [ ] Booking link live  
- [ ] Soft launch: send the Payment Link to 1 warm lead or post to your audience when *you* approve

## Part D — First-sale hygiene
- Screenshot your Stripe test payment once before going live.  
- Never paste secret keys into chat, Notion, or Instagram DMs.  
- Use a dedicated support inbox you actually check.
