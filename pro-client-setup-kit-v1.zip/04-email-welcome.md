# Email 1 — Welcome (send right after payment)

**Subject:** You’re in — here’s your client setup

Hi [First name],

Thank you for investing in yourself. I’m looking forward to working together.

Here’s everything for a clean start:

1. **Complete your intake** (5–7 min): [INTAKE FORM LINK]  
2. **Review & sign the agreement**: [AGREEMENT LINK]  
3. **Book Session 1**: [BOOKING LINK]

Please finish the intake before Session 1 so we can use our time on you — not on catching up.

If anything in the links is unclear, reply to this email. I’ve got you.

Glad you’re here,  
[Your Name]  
[Your website or Beacons link]
