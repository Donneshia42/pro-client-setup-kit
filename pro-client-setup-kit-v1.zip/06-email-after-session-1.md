# Email 3 — After Session 1 (send within 24 hours)

**Subject:** Session 1 recap + your one action

Hi [First name],

Proud of you for showing up. Here’s what I heard today:

**Focus:** [their 90-day focus in their words]  
**This week’s one action:** [the single action you agreed]  
**Next session:** [date/time] — booking link if needed: [LINK]

Reply to this email when the action is done (or if you’re stuck). Short replies are perfect.

Rooting for you,  
[Your Name]
