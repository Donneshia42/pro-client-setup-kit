# Welcome Packet — text you can paste into Google Docs or Canva

**Title:** Welcome to coaching with [Your Name]

---

## You’re in the right place
I’m glad you’re here. Coaching with me is a partnership: you bring the goals and honesty; I bring structure, reflection, and accountability. We’ll keep it human and professional.

## How we work together
1. **You pay** via my Stripe link (keeps everything clean).  
2. **You book** Session 1 on my calendar link.  
3. **You complete** the intake form before we meet.  
4. **You review/sign** the coaching agreement.  
5. **We meet** — cameras on if Zoom, phone muted from distractions.

## What to expect in Session 1
We’ll clarify your 90-day focus, what “done” looks like, and the one habit or action that matters most this week. You leave with a clear next step — not a pile of vague inspiration.

## Between sessions
- Do the agreed action. Small beats perfect.  
- Reply to my check-in email if something’s stuck.  
- Reschedule with 24+ hours notice when life happens.

## Boundaries (said with love)
- Coaching isn’t therapy or medical care.  
- I’m not available 24/7 for crisis support — if you’re in danger, call local emergency services.  
- Respect goes both ways: no-shows and chronic lateness cost us both momentum.

## Links you’ll need
- Payment: [your Stripe Payment Link]  
- Booking: [your Calendly / Google Appointment schedule]  
- Intake form: [your Google Form]  
- Agreement: [Doc link or attached PDF]

## Contact
Email: [your email]  
Typical reply window: [e.g. 1 business day]

Welcome. Let’s build something you’re proud of.
— [Your Name]
