# Email 2 — Before Session 1 (send 24 hours prior)

**Subject:** Tomorrow’s session — one thing to bring

Hi [First name],

Quick reminder: we meet **[Day], [Time + time zone]** on [Zoom/phone link].

Please bring:
- One goal you want progress on in the next 90 days  
- One thing that’s been getting in the way  
- A quiet place and a charged device

If you need to reschedule, reply with 24+ hours notice when you can.

See you soon,  
[Your Name]
